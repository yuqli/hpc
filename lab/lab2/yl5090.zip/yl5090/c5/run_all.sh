sbatch submit-gpu-24-adadelta.sh  
sbatch submit-gpu-24-adam.sh      
sbatch submit-gpu-24-sgd.sh
sbatch submit-gpu-1.sh  
sbatch submit-gpu-24-adagrad.sh   
sbatch submit-gpu-24-nesterov.sh
